#ifndef SERIAL_H
#define SERIAL_H

#include "../types.h"

// Tableau des ports COM standards (COM1..COM4), défini dans serial.c.
// Déclaré ici à titre indicatif : le contrat utilisé par le reste du
// kernel est celui de sys/io.h (extern u16 *coms;).

// If you have a print function for serial, add it here too:
// void serial_write(char a);

#endif