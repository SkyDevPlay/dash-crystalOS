# Check-up dash-crystalOS — Rapport de correctifs

J'ai relu tout le code (bootloader, kernel, FAT, malloc, string, io, serial)
et testé la logique avec des simulations Python sur les vraies données de
`part.bin`. Trois bugs indépendants empêchaient le système de fichiers de
fonctionner, plus deux bugs mineurs corrigés au passage.

## Bug critique n°1 — Mauvais LBA pour la FAT et le root dir (boot.asm)

`mkfs.fat` génère une partition avec **4 secteurs réservés**
(`resv_sectors = 4`, confirmé en parsant `part.bin`), mais le bootloader
supposait 1 seul secteur réservé. Il chargeait donc :
- la "FAT table" depuis LBA `PART_LBA+1` → en réalité des secteurs réservés
  *vides*.
- le "root directory" depuis LBA `PART_LBA+129` → en réalité encore dans la
  FAT, donc vide aussi.

Résultat : le kernel voyait une FAT et un root dir entièrement à zéro →
`_ls` ne listait rien, `_sw <fichier>` ne trouvait jamais aucun fichier.

**Fix** (`boot/boot.asm`) : chargement à `PART_LBA+4` (FAT) et
`PART_LBA+4+128` (root dir), conformément aux vrais `resv_sectors=4` et
`fat_count=2 × sectors_per_fat=64`.

## Bug critique n°2 — `MediaDescriptor` en `enum` (4 octets) au lieu de `u8` (include/fat.h)

```c
typedef enum{ disk = 0xF8 } MediaDescriptor;   // GCC le stocke sur 4 octets !
...
MediaDescriptor media_descriptor;               // devrait faire 1 octet
```

Un `enum` C fait généralement la taille d'un `int` (4 octets), même packé.
Comme ce champ est au milieu de `struct fat_bootsector`, **tous les champs
suivants étaient décalés de 3 octets** — en particulier `sectors_per_fat`,
qui se retrouvait lu à la valeur `1024` au lieu de `64`. Le calcul de
`root_addr`/`data_addr` dans `init_fs()` était donc complètement faux,
même une fois le bug n°1 corrigé.

**Fix** : remplacé par `u8 media_descriptor;` (+ une `#define` à la place
de l'enum). Vérifié avec un test `sizeof`/`offsetof` que la structure fait
maintenant exactement 512 octets avec tous les offsets alignés sur le
format binaire FAT16 standard.

## Bug critique n°3 — Déclarations incompatibles de `coms` / `initSerial`

Deux headers différents déclaraient les mêmes symboles avec des types
incompatibles :
- `include/sys/io.h` (utilisé par `kernel.c`) : `extern u16 *coms;` et
  `int initSerial(u16 port);`
- `include/sys/serial.h` (utilisé par `serial.c`) : `extern int coms;` et
  `void initSerial(void);`

Le linker ne vérifie pas les types entre unités de compilation : ça
linkait "sans erreur" mais `kernel.c` appelait `initSerial(coms[0])` en
traitant un simple `int` comme un tableau de `u16*` — comportement indéfini
au démarrage, potentiellement un crash avant même d'atteindre `init_fs()`.

**Fix** (`krnl/sys/serial.c` + `include/sys/serial.h`) : implémentation
réelle de `initSerial(u16 port)` (init UART 8250/16450 standard), `coms`
et `lpts` redéfinis comme tableaux de `u16` conformes au contrat de
`io.h`, et ajout de `writeSerial`/`readSerial`/`serialString` qui étaient
déclarées mais jamais implémentées.

## Bug mineur — `printf("%c", ...)` non géré (krnl/io.c)

`read_file()` utilisait `printf("%c", buf[i])`, mais `printf` ne gérait
que `%d`, `%x`, `%s`. Tout autre spécificateur tombait dans un `default`
qui écrivait "ERR" dans un buffer jamais affiché (donc silencieux).
**Fix** : ajout du cas `%c`, et le `default` affiche maintenant
réellement "ERR" pour rendre visibles d'éventuelles futures erreurs de
format.

## Bug mineur — `_itoa(0, ...)` n'écrivait rien (krnl/io.c)

`_itoa` ne gérait pas le cas `value == 0` (la boucle `while(value>0)` ne
s'exécute jamais), donc `printf("%d", 0)` n'affichait rien au lieu de "0".
**Fix** : cas spécial ajouté.

## Amélioration — persistance des écritures (`fwrite`, krnl/fat.c)

`fwrite()` modifiait la FAT et la taille du fichier uniquement en RAM,
sans jamais réécrire les secteurs correspondants sur le disque. Au
redémarrage, toute écriture qui agrandissait un fichier ou allouait un
nouveau cluster était perdue / désynchronisée.
**Fix** : ajout d'un champ `dir_index` dans `FILE`, et de deux fonctions
internes (`sync_fat_sector`, `sync_dir_entry`) qui réécrivent sur disque
le secteur FAT modifié et le secteur du root dir modifié dès qu'un
nouveau cluster est alloué ou que la taille du fichier change.

---

## Comment vérifier

Cet environnement ne dispose pas de la toolchain croisée `i686-elf-gcc`/
`nasm`/QEMU (et pas d'accès réseau pour les installer), je n'ai donc pas
pu reconstruire `os.bin` ni le lancer dans un émulateur. En revanche :

- **Tous les fichiers `.c` compilent sans erreur** (vérifié avec gcc
  générique `-Wall -Wextra -m32 -fpack-struct -ffreestanding -nostdlib
  -fsyntax-only`, mêmes flags que le `Makefile`).
- **Le link complet réussit** sans symbole manquant ni dupliqué (testé
  avec des stubs pour les fonctions assembleur).
- **La logique du bootloader corrigé + `init_fs` + lecture de fichier a
  été simulée en Python directement sur les vraies données de
  `part.bin`** : `_ls` retrouve bien `HELLO.TXT` (21 octets, cluster 3) et
  `TEST.TXT` (17 octets, cluster 4), et la lecture du contenu de
  `HELLO.TXT` donne bien `"Hello DashCrystalOS!\n"`.

Pour valider en conditions réelles chez vous :
```
make clean
make
make run
```
puis dans le shell : `_ls`, `_sw HELLO.TXT`, `_sw TEST.TXT`.
