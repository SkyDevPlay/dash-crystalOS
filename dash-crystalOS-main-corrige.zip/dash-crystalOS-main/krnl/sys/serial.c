#include "sys/serial.h"
#include "sys/io.h"
#include "sys/ports.h" // You'll need this to use inb/outb/outw/inw

// Ports COM standards (COM1..COM4) et LPT standards (LPT1..LPT3).
// Tableaux requis par le contrat de sys/io.h (extern u16 *coms / *lpts).
u16 coms_table[4] = { 0x3F8, 0x2F8, 0x3E8, 0x2E8 };
u16 lpts_table[3] = { 0x378, 0x278, 0x3BC };
u16 *coms = coms_table;
u16 *lpts = lpts_table;

int initSerial(u16 port) {
    outb(port + 1, 0x00);    // Disable interrupts
    outb(port + 3, 0x80);    // Enable DLAB (set baud rate divisor)
    outb(port + 0, 0x03);    // Set divisor to 3 (38400 baud)
    outb(port + 1, 0x00);
    outb(port + 3, 0x03);    // Disable DLAB, 8 bits, no parity, 1 stop bit
    outb(port + 2, 0xC7);    // Enable FIFO, clear them, 14-byte threshold
    outb(port + 4, 0x0B);    // IRQs enabled, RTS/DSR set
    outb(port + 4, 0x1E);    // Set in loopback mode to test the serial chip
    outb(port + 0, 0xAE);    // Test serial chip with byte 0xAE

    if (inb(port + 0) != 0xAE) return -1; // Chip absent / non répondant

    outb(port + 4, 0x0F);    // Not in loopback mode, normal operation
    return 0;
}

void writeSerial(u16 port, u8 c) {
    while (!(inb(port + 5) & 0x20));
    outb(port, c);
}

u8 readSerial(u16 port) {
    while (!(inb(port + 5) & 0x01));
    return inb(port);
}

void serialString(u16 port, char *str) {
    while (*str) writeSerial(port, (u8)*str++);
}